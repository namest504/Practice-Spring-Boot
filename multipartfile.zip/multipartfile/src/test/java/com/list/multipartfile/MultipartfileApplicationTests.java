package com.list.multipartfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipartfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
